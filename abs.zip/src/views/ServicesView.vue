<template>
   <div class="services">
    <img src="./images/services.jpg" class="img-fluid">
    <p class="para">OUR SERVICES</p>
    <ServicesView2 />
     <div>
           <FooterView v-bind:url_data="url_data">
           </FooterView>
        </div>
  </div>
</template>

<script>
import ServicesView2 from './ServicesView2'
import FooterView from './FooterView'
export default{
    name: 'ServicesView',
    components:{
        ServicesView2,
        FooterView
    },
     mounted(){
     this.url_data=this.$route.name;
    },
  data(){
    return{
      url_data: ""
     //loc:"scn"
    }
  },
}
</script>

<style scoped>
.services img{
  max-width:100%;
  min-height:500px;
  opacity:0.88;
}
.para{
    left: 0;
  position: absolute;
  text-align: center;
  top: 38%;
  width: 100%;
  font-size:25px;
  font-weight: bold;
  color:black;
}
</style>