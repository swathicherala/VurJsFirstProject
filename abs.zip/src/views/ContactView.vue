<template>
   <div class="contact">
    <img src="./images/contact.jpg" class="img-fluid">
    <p class="para">CONTACT US</p>
    <ContactView2 />
       <div>
           <FooterView v-bind:url_data="url_data">
           </FooterView>
        </div>
  </div>
</template>

<script>
import ContactView2 from './ContactView2'
import FooterView from './FooterView'
export default{
    name:'ContactView',
    components:{
      ContactView2,
      FooterView
    },
    mounted(){
     this.url_data=this.$route.name;
    },
  data(){
    return{
      url_data: ""
     //loc:"scn"
    }
  },
}
</script>

<style scoped>
.contact img{
  max-width:100%;
  min-height:500px;
  opacity:0.8;
}
.para{
    left: 0;
  position: absolute;
  text-align: center;
  top: 38%;
  width: 100%;
  font-size:25px;
  font-weight: bold;
  color:black;
}
@media only screen and (max-width:500px) {
  .contact{
    max-width: 100%;
    padding:0px;
    margin:0px;
  }
  .contact .img-fluid{
    max-width: 124%;
  }
}
</style>
